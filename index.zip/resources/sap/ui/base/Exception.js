/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2014 SAP AG. All rights reserved
 */
sap.ui.define(['jquery.sap.global'],function(q){"use strict";var E=function(m){this.name="Exception";this.message=m};return E},true);
