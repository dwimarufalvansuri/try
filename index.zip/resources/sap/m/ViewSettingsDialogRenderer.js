/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2014 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.m.ViewSettingsDialogRenderer");sap.m.ViewSettingsDialogRenderer={};
sap.m.ViewSettingsDialogRenderer.render=function(r,c){};
