/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2014 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.m.CustomTile");jQuery.sap.require("sap.m.library");jQuery.sap.require("sap.m.Tile");sap.m.Tile.extend("sap.m.CustomTile",{metadata:{library:"sap.m",defaultAggregation:"content",aggregations:{"content":{type:"sap.ui.core.Control",multiple:false}}}});
